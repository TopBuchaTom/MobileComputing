import { LanguageService } from "../../core/language-service";

// Export original class, because there is no logic to mock
export { LanguageService as DummyLanguageService };
