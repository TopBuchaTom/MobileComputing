import "./components/ionic/global-integration";
import "./components/page/global-integration";