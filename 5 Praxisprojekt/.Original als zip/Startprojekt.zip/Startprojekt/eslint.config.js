// eslint.config.js
export default [
    {
        rules: {
            "no-unused-vars": [2, { "vars": "all", "args": "none" }],
        }
    }
];