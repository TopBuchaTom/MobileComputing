import { SettingsService } from "../../core/settings-service";

// Export original class, because there is no logic to mock
export { SettingsService as DummySettingsService };
