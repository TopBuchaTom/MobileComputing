import { ColorschemeService } from "../../core/colorscheme-service";

// Export original class, because there is no logic to mock
export { ColorschemeService as DummyColorschemeService };
