import { RouterService } from "../../core/router-service";

// Export original class, because there is no logic to mock
export { RouterService as DummyRouterService };
